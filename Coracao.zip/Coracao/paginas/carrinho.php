<div class="titulo">
    <h1>Carrinho</h1>
</div>